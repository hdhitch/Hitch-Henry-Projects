#!/usr/bin/env python
# coding: utf-8

# # A.i #

# In[1]:


from astropy.io import fits as pyfits
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


# In[2]:


def pause():
    
    # pauses until a keyboard entry (e.g. carrage return)
    
    print('\r')     
    dummy = input('Pause')     
    print('\r')


# In[3]:


RedRDC1702 = pyfits.open('20050702.1702.HW.R.P.rdc.fits.gz')           # Use the astropy.io module to read the fits data of the earliest red continuum and earliest CaIIK rdc and contrast images of the day into arrays
RedContrast1702 = pyfits.open('20050702.1702.HW.R.P.contrast.fits.gz')

CalRDC1702 = pyfits.open('20050702.1702.HW.K.P.rdc.fits.gz')
CalContrast1702 = pyfits.open('20050702.1702.HW.K.P.contrast.fits.gz')


# In[4]:


RedRDC1702[0].header                                          # extract the header so I can look at it
header = pyfits.getheader('20050702.1702.HW.R.P.rdc.fits.gz') 


# In[5]:


imRedRDC1702 = RedRDC1702[0].data         # extract the RDC image data from the files
imRcontrast1702 = RedContrast1702[0].data # extract the contrast image data from the files

imCalRDC1702 = CalRDC1702[0].data
imCalContrast1702 = CalContrast1702[0].data


# In[6]:


fig, ax = plt.subplots(2, 2, figsize = (10, 10)) # define figure and axes for subplot

ax[0, 0].imshow(imRedRDC1702, cmap='gray')       # use imshow to display the images
ax[0, 0].set_title('1702 Red RDC Image')

ax[0, 1].imshow(imRcontrast1702, cmap='gray')
ax[0, 1].set_title('1702 Red Contrast Image')

ax[1, 0].imshow(imCalRDC1702, cmap='gray')
ax[1, 0].set_title('1702 Calcium RDC Image')

ax[1, 1].imshow(imCalContrast1702, cmap='gray')
ax[1, 1].set_title('1702 Calcium Contrast Image')

pause()


# # A.ii #

# In[7]:


x, y = np.shape(imRedRDC1702) # find the shape of the images and set them to variables


# In[8]:


HcutRedRDC = imRedRDC1702[int(x/2), :]           # cut the Red RDC image at the center
HcutCalRDC = imCalRDC1702[int(x/2), :]           # cut the Calcium RDC image at the center

HcutRContrast = imRcontrast1702[int(x/2), :]     # cut the Red contrast image at the center
HcutCalContrast = imCalContrast1702[int(x/2), :] # cut the Calcium contrast image at the center


# In[9]:


fig2, ax2 = plt.subplots(1, 2, figsize = (15, 5))         # define figure and axes for subplot

ax2[0].plot(HcutRedRDC)                                   # plot the RDC horizontal cut images
ax2[0].set_title('1702 Red RDC Image Horizontal Cut')

ax2[1].plot(HcutCalRDC)
ax2[1].set_title('1702 Calcium RDC Image Horizontal Cut')

pause()


# In[10]:


fig3, ax3 = plt.subplots(1, 2, figsize = (15, 5))

ax3[0].plot(HcutRContrast)                                    # plot the contrast horizontal cut images
ax3[0].set_title('1702 Red Contrast Image Horizontal Cut')

ax3[1].plot(HcutCalContrast)
ax3[1].set_title('1702 Calcium Contrast Image Horizontal Cut')

pause()


# # B.i #

# In[11]:


def imgData(file1, file2):                      # define a function for opening and extracting the specific data
    '''
    Takes:
        Two strings of file names with data
        
    Parameters:
        file1 : a string of your desired file name containing data, with same time as file2
        file2 : a string of your desired file name containing data, with same time as file1
        
    Returns:
        A 2-D numpy array with the time, average width, and RMSA data for both filter RDC data
    '''
    data1 = pyfits.open(file1)                  # use astropy.io to open the files
    data2 = pyfits.open(file2)
    
    time = data1[0].header['JULDATE']           # extract the time variable from the header of one of the files
    
    avgWidth1 = data1[0].header['AVGWIDTH']     # extract the Average Width data from the headers of the files
    avgWidth2 = data2[0].header['AVGWIDTH']
    
    rmsa1 = data1[0].header['RMSA']             # extract the RMSA data from the headers of the files
    rmsa2 = data2[0].header['RMSA']
    
    array1 = np.array([time, avgWidth1, rmsa1]) # define arrays for the both files, containing the time, average width, and RMSA data
    array2 = np.array([time, avgWidth2, rmsa2])
    
    finalArray = np.array([array1, array2])     # define a final array with both file arrays inside
    
    return finalArray                           # return the final array


# In[12]:


rdcData1702 = imgData('20050702.1702.HW.R.P.rdc.fits.gz', '20050702.1702.HW.K.P.rdc.fits.gz') # use my function imgData to easily extract all the time, average width, and RMSA data for each image and filter
print(rdcData1702)


# In[13]:


rdcData1720 = imgData('20050702.1720.HW.R.P.rdc.fits.gz', '20050702.1720.HW.K.P.rdc.fits.gz') # do the same for the rest of the files
print(rdcData1720)


# In[ ]:


rdcData1740 = imgData('20050702.1740.HW.R.P.rdc.fits.gz', '20050702.1740.HW.K.P.rdc.fits.gz')
print(rdcData1740)


# In[ ]:


rdcData1802 = imgData('20050702.1802.HW.R.P.rdc.fits.gz', '20050702.1802.HW.K.P.rdc.fits.gz')
print(rdcData1802)


# In[ ]:


rdcData1820 = imgData('20050702.1820.HW.R.P.rdc.fits.gz', '20050702.1820.HW.K.P.rdc.fits.gz')
print(rdcData1820)


# In[ ]:


rdcData1840 = imgData('20050702.1840.HW.R.P.rdc.fits.gz', '20050702.1840.HW.K.P.rdc.fits.gz')
print(rdcData1840)


# In[ ]:


timeArray = np.array([rdcData1702[0, 0], rdcData1720[0, 0], rdcData1740[0, 0], rdcData1802[0, 0], rdcData1820[0, 0], rdcData1840[0, 0], ])
print(timeArray)


# In[ ]:


avgRedWidth = np.array([rdcData1702[0, 1], rdcData1720[0, 1], rdcData1740[0, 1], rdcData1802[0, 1], rdcData1820[0, 1], rdcData1840[0, 1]]) # extract the average width data for all the Red filter images
avgCalWidth = np.array([rdcData1702[1, 1], rdcData1720[1, 1], rdcData1740[1, 1], rdcData1802[1, 1], rdcData1820[1, 1], rdcData1840[1, 1]]) # extract the average width data for all the Calcium filter images


# In[ ]:


RedRMSA = np.array([rdcData1702[0, 2], rdcData1720[0, 2], rdcData1740[0, 2], rdcData1802[0, 2], rdcData1820[0, 2], rdcData1840[0, 2]]) # extract the RMSA data for all the Red filter images
CalRMSA = np.array([rdcData1702[1, 2], rdcData1720[1, 2], rdcData1740[1, 2], rdcData1802[1, 2], rdcData1820[1, 2], rdcData1840[1, 2]]) # extract the RMSA data for all the Calcium filter images


# # B.ii #

# In[ ]:


plt.plot(timeArray, avgRedWidth, label='Red Filter', color = 'r')      # plot average width vs. time for both filters
plt.plot(timeArray, avgCalWidth, label='Calcium Filter', color = 'b');

plt.title('Average Width vs. Time')
plt.xlabel('Time [Julian Date]')
plt.ylabel('Average Width')

plt.legend()

pause()


# In[ ]:


plt.plot(timeArray, RedRMSA, label='Red Filter', color = 'r')      # plot RMSA vs. time for both filters
plt.plot(timeArray, CalRMSA, label='Calcium Filter', color = 'b');

plt.title('RMSA vs. Time')
plt.xlabel('Time [Julian Date]')
plt.ylabel('RMSA')

plt.legend()

pause()


# # C.i #

# In[ ]:


RedRDC1720 = pyfits.open('20050702.1720.HW.R.P.rdc.fits.gz')           # Use the astropy.io module to read the fits data of the next files
RedContrast1720 = pyfits.open('20050702.1720.HW.R.P.contrast.fits.gz')

CalRDC1720 = pyfits.open('20050702.1720.HW.K.P.rdc.fits.gz')
CalContrast1720 = pyfits.open('20050702.1720.HW.K.P.contrast.fits.gz')


# In[ ]:


RedRDC1740 = pyfits.open('20050702.1740.HW.R.P.rdc.fits.gz')
RedContrast1740 = pyfits.open('20050702.1740.HW.R.P.contrast.fits.gz') 

CalRDC1740 = pyfits.open('20050702.1740.HW.K.P.rdc.fits.gz')
CalContrast1740 = pyfits.open('20050702.1740.HW.K.P.contrast.fits.gz')


# In[ ]:


imRedRDC1720 = RedRDC1720[0].data         # extract the RDC image data from the files
imRcontrast1720 = RedContrast1720[0].data # extract the contrast image data from the files

imCalRDC1720 = CalRDC1720[0].data
imCalContrast1720 = CalContrast1720[0].data


# In[ ]:


imRedRDC1740 = RedRDC1740[0].data
imRcontrast1740 = RedContrast1740[0].data

imCalRDC1740 = CalRDC1740[0].data
imCalContrast1740 = CalContrast1740[0].data


# In[ ]:


RedDiskContrast1702 = (imRcontrast1702 != np.min(imRcontrast1702))*imRcontrast1702 # define new arrays that remove the background from the first 3 Red images
RedDiskContrast1720 = (imRcontrast1720 != np.min(imRcontrast1720))*imRcontrast1720
RedDiskContrast1740 = (imRcontrast1740 != np.min(imRcontrast1740))*imRcontrast1740


# In[ ]:


CalDiskContrast1702 = (imCalContrast1702 != np.min(imCalContrast1702))*imCalContrast1702 # define new arrays that remove the background from the first 3 Calcium images
CalDiskContrast1720 = (imCalContrast1720 != np.min(imCalContrast1720))*imCalContrast1720
CalDiskContrast1740 = (imCalContrast1740 != np.min(imCalContrast1740))*imCalContrast1740


# In[ ]:


fig4, ax4 = plt.subplots(1, 2, figsize = (15, 5))

fig4.suptitle('Contrast Histograms')

ax4[0].hist(RedDiskContrast1702.flatten(), density = True, alpha = 0.5, label = '1702') # flatten the 2-D images into 1-D arrays and plot histograms of the 3 Red contrast images
ax4[0].hist(RedDiskContrast1720.flatten(), density = True, alpha = 0.5, label = '1720') 
ax4[0].hist(RedDiskContrast1740.flatten(), density = True, alpha = 0.5, label = '1740')
ax4[0].set_title('Red Filter')
ax4[0].set_yscale('log')                                                                # set the y-axis to a log scale
ax4[0].set_xlim(-0.8, 0.2)                                                              # set x limits so we can compare the histograms with time
ax4[0].set_xlabel('Pixel Intensity')
ax4[0].set_ylabel('Number of Occurences')
ax4[0].legend()

ax4[1].hist(CalDiskContrast1702.flatten(), density = True, alpha = 0.5, label = '1702') # repeat for Calcium filter
ax4[1].hist(CalDiskContrast1720.flatten(), density = True, alpha = 0.5, label = '1720')
ax4[1].hist(CalDiskContrast1740.flatten(), density = True, alpha = 0.5, label = '1740')
ax4[1].set_title('Calcium Filter')
ax4[1].set_yscale('log')
ax4[1].set_xlim(-1, 1.5)
ax4[1].set_xlabel('Pixel Intensity')
ax4[1].set_ylabel('Number of Occurences')
ax4[1].legend()

pause()


# # C.ii #

# In[ ]:


RedRDC1802 = pyfits.open('20050702.1802.HW.R.P.rdc.fits.gz')           # Use the astropy.io module to read the fits data of the next files
RedContrast1802 = pyfits.open('20050702.1802.HW.R.P.contrast.fits.gz')

CalRDC1802 = pyfits.open('20050702.1802.HW.K.P.rdc.fits.gz')
CalContrast1802 = pyfits.open('20050702.1802.HW.K.P.contrast.fits.gz')


# In[ ]:


RedRDC1820 = pyfits.open('20050702.1820.HW.R.P.rdc.fits.gz')
RedContrast1820 = pyfits.open('20050702.1820.HW.R.P.contrast.fits.gz')

CalRDC1820 = pyfits.open('20050702.1820.HW.K.P.rdc.fits.gz')
CalContrast1820 = pyfits.open('20050702.1820.HW.K.P.contrast.fits.gz')


# In[ ]:


RedRDC1840 = pyfits.open('20050702.1840.HW.R.P.rdc.fits.gz')
RedContrast1840 = pyfits.open('20050702.1840.HW.R.P.contrast.fits.gz')

CalRDC1840 = pyfits.open('20050702.1840.HW.K.P.rdc.fits.gz')
CalContrast1840 = pyfits.open('20050702.1840.HW.K.P.contrast.fits.gz')


# In[ ]:


imRedRDC1802 = RedRDC1802[0].data         # extract the RDC image data from the files
imRcontrast1802 = RedContrast1802[0].data # extract the contrast image data from the files

imCalRDC1802 = CalRDC1802[0].data
imCalContrast1802 = CalContrast1802[0].data


# In[ ]:


imRedRDC1820 = RedRDC1820[0].data
imRcontrast1820 = RedContrast1820[0].data

imCalRDC1820 = CalRDC1820[0].data
imCalContrast1820 = CalContrast1820[0].data


# In[ ]:


imRedRDC1840 = RedRDC1840[0].data
imRcontrast1840 = RedContrast1840[0].data

imCalRDC1840 = CalRDC1840[0].data
imCalContrast1840 = CalContrast1840[0].data


# In[ ]:


RedDiskContrast1802 = (imRcontrast1802 != np.min(imRcontrast1802))*imRcontrast1802 # define new arrays that remove the background from the last 3 Red images
RedDiskContrast1820 = (imRcontrast1820 != np.min(imRcontrast1820))*imRcontrast1820
RedDiskContrast1840 = (imRcontrast1840 != np.min(imRcontrast1840))*imRcontrast1840


# In[ ]:


CalDiskContrast1802 = (imCalContrast1802 != np.min(imCalContrast1802))*imCalContrast1802 # define new arrays that remove the background from the last 3 Calcium images
CalDiskContrast1820 = (imCalContrast1820 != np.min(imCalContrast1820))*imCalContrast1820
CalDiskContrast1840 = (imCalContrast1840 != np.min(imCalContrast1840))*imCalContrast1840


# In[ ]:


redVariance = np.array([np.var(RedDiskContrast1702), np.var(RedDiskContrast1720), np.var(RedDiskContrast1740), np.var(RedDiskContrast1802), np.var(RedDiskContrast1820), np.var(RedDiskContrast1840)]) # use np.var to calculate the variance (second moment) of each Red contrast image


# In[ ]:


calVariance = np.array([np.var(CalDiskContrast1702), np.var(CalDiskContrast1720), np.var(CalDiskContrast1740), np.var(CalDiskContrast1802), np.var(CalDiskContrast1820), np.var(CalDiskContrast1840)]) # use np.var to calculate the variance (second moment) of each Calcium contrast image


# In[ ]:


plt.plot(timeArray, redVariance)            # plot the Red variance vs. time
plt.title('Red Contrast Variance vs. Time') # title plot
plt.ylabel('Red Filter Contrast Variance')  # label axes
plt.xlabel('Time [Julian Date]')

pause()


# In[ ]:


plt.plot(timeArray, calVariance)                # plot the Calcium variance vs. time
plt.title('Calcium Contrast Variance vs. Time') # title plot
plt.ylabel('Calcium Filter Contrast Variance')  # label axes
plt.xlabel('Time [Julian Date]')

pause()


# # C.iii #

# In[ ]:


plt.scatter(avgRedWidth, redVariance)       # scatter plot Red variance vs. Average Red Width
plt.title('Red Variance vs. Average Width') # title plot
plt.ylabel('Variance')                      # label axes
plt.xlabel('Average Width')

pause()


# In[ ]:


plt.scatter(avgCalWidth, calVariance)           # scatter plot Calcium variance vs. Average Calcium Width
plt.title('Calcium Variance vs. Average Width') # title plot
plt.ylabel('Variance')                          # label axes
plt.xlabel('Average Width')

pause()


# In[ ]:




