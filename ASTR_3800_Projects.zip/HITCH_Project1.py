#!/usr/bin/env python
# coding: utf-8

# ### Henry Hitch 
# ### ASTR 3800 Project 1
# ### Collaborated with Niki Tanev

# In[1]:


import numpy as np
import matplotlib.pyplot as plt
import scipy
import scipy.stats as stats


# In[2]:


def pause():
    
    # pauses until a keyboard entry (e.g. carrage return)
    
    print('\r')     
    dummy = input('Pause')     
    print('\r')


# # Ai. #

# In[3]:


np.random.seed(1)
uniform1 = np.random.uniform(0, 1, 1000);


# In[4]:


np.random.seed(2)
uniform2 = np.random.uniform(0, 1, 1000);


# In[5]:


np.random.seed(3)
uniform3 = np.random.uniform(0, 1, 1000);


# In[6]:


fig1, axs1 = plt.subplots(1, 3, figsize=(20,5))               # Create figure and axis for subplotting

axs1[0].plot(uniform1)                                        # Plot and set title
axs1[0].set_title('A)')

axs1[1].plot(uniform2)
axs1[1].set_title('B)')

axs1[2].plot(uniform3)
axs1[2].set_title('C)')

for ax in axs1.flat:                                          # For loop that labels x and y axes
    ax.set(xlabel='Series Element', ylabel='"Random" Number')
    
plt.show()                                                    # Makes plots visible in command line

pause()                                                       # Pause function: hit Enter to continue


# It's good practice to specify the seed (especially when debugging code) because it allows you to recreate the exact same scenarios. Reduces the number of changing variables.

# # Aii. #

# In[7]:


def nuemann(x, y):
    '''
    Takes:
        A 6-digit seed number [x], and returns a list length [y + 1] of random numbers
    
    Parameters:
        x : 6-digit seed
        y : desired length of list - 1
        
    Returns:
        List length [y + 1] full of psuedo-random numbers using Jon Von Nuemanns original technique
    '''
    
    first = str(x**2)             # First seed gets squared and converted into a string for splicing
    
    list1 = [x]                   # Define a list that starts with our input seed
    
    for i in range(y):
        newSeed = int(first[3:9]) # First string is spliced to take the middle 6 digits and turn them back into an integer
        
        first = str(newSeed**2)   # Redefine the string as the new seed squared
        
        list1.append(newSeed)     # Append the new seed to list1
            
    return list1                  # Return list 1


# In[8]:


nuemann1 = np.array(nuemann(315403, 1000))/1e6
nuemann2 = np.array(nuemann(977631, 1000))/1e6
nuemann3 = np.array(nuemann(494239, 1000))/1e6


# In[9]:


fig2, axs2 = plt.subplots(1, 3, figsize=(20,5))

axs2[0].plot(nuemann1)
axs2[0].set_title('D)')

axs2[1].plot(nuemann2)
axs2[1].set_title('E)')

axs2[2].plot(nuemann3)
axs2[2].set_title('F)')

for ax in axs2.flat:
    ax.set(xlabel='Series Element', ylabel='"Random" Number')
    
plt.show()

pause()


# For plots 1 and 3, you can see they both get stuck in a loop on the number 625, because 625^2 = 390625 which ends in 625, causing it to fall into a loop. For plot 2, the pattern visually repeats which indicates that it's stuck in a repeating loop.

# # Aiii. #

# In[10]:


def nuemannUpdated(x, y):
    '''
    Takes: 
        A 6-digit seed number [x], and returns a list length [y + 1] of pseudo-random numbers
    
    Parameters:
        x : 6-digit seed
        y : desired length of list
        
    Returns:
        List length [y + 1] full of psuedo-random numbers using an updated Nuemann technique which doesnt generate infinite loops or 0s as often
    '''
    
    
    first = str(x**2)                           # First seed gets squared and converted into a string for splicing
    
    list1 = [x]                                 # Define a list that starts with our input seed
    
    for i in range(y):
        
        newSeed = int(first[3:9])
        
        if newSeed%100 == 0 or newSeed < 100000: # If the new seed is evenly divisble by 100 or less than 6 digits, does something different with the number
            
            first = str((newSeed+123456)**2)     # Takes the current seed and adds 123456 to it
            
            list1.append(newSeed)                # Appends back to the list
            
        else:                                    # Otherwise, applies Jon Von Nuemann's original techinque 
            first = str(newSeed**2)
            list1.append(newSeed)
            
    return list1


# In[11]:


nuemannUp1 = np.array(nuemannUpdated(195703, 1000))/1e6
nuemannUp2 = np.array(nuemannUpdated(641596, 1000))/1e6
nuemannUp3 = np.array(nuemannUpdated(156455, 1000))/1e6


# In[12]:


fig3, axs3 = plt.subplots(1, 3, figsize=(20,5))

axs3[0].plot(nuemannUp1)
axs3[0].set_title('G)')

axs3[1].plot(nuemannUp2)
axs3[1].set_title('H)')

axs3[2].plot(nuemannUp3);
axs3[2].set_title('I)')

for ax in axs3.flat:
    ax.set(xlabel='Series Element', ylabel='"Random" Number')
    
plt.show()

pause()


# Something problematic about making these corrections is that now we wont see any numbers ending in 00, which we should expect if it was truly random. Also, by adding 123456, while it might make up for the fact that sometimes the function produces lower digit seeds, it creates a uniform change that obviously still creates other patterns. 

# # Aiv. #

# In[13]:


humanRandom = np.load('human.npz')


# In[14]:


human1 = humanRandom['human1']
human2 = humanRandom['human2']
human3 = humanRandom['human3']


# In[15]:


fig4, axs4 = plt.subplots(1, 3, figsize=(20,5))

axs4[0].plot(human1)
axs4[0].set_title('J)')

axs4[1].plot(human2)
axs4[1].set_title('K)')

axs4[2].plot(human3);
axs4[2].set_title('L)')

for ax in axs4.flat:
    ax.set(xlabel='Series Element', ylabel='"Random" Number')
    
plt.show()

pause()


# There are very noticeable visual differences between my random number generation techniques. The first 3 plots are the most "random", as they appear to have no discernable pattern. My plots with the 2 differnet Nuemann techniques all clearly have visual patterns, except for plot H). My last plots for the human trial appear just as random as my numpy.uniform plots, excpet K) appears to have some periodic form to it. 

# # Bii. #

# In[16]:


fig5, axs5 = plt.subplots(1, 4, figsize=(25,5))

axs5[0].hist(uniform1, bins=10)
axs5[0].set_title('A)')

axs5[1].hist(uniform2, bins=10)
axs5[1].set_title('B)')

axs5[2].hist(uniform3, bins=10)
axs5[2].set_title('C)')

axs5[3].hist((uniform1 + uniform2 + uniform3)/3, bins=10)
axs5[3].set_title('D)')

for ax in axs5.flat:
    ax.set(xlabel='Value', ylabel='# of Times Value Appeared')
    
plt.show()

pause()


# In[17]:


fig6, axs6 = plt.subplots(1, 4, figsize=(25,5))

axs6[0].hist(uniform1, bins=40, color='g')
axs6[0].set_title('E)')

axs6[1].hist(uniform2, bins=40, color='g')
axs6[1].set_title('F)')

axs6[2].hist(uniform3, bins=40, color='g')
axs6[2].set_title('G)')

axs6[3].hist((uniform1 + uniform2 + uniform3)/3, bins=40, color='g')
axs6[3].set_title('H)')

for ax in axs6.flat:
    ax.set(xlabel='Value', ylabel='# of Times Value Appeared')
    
plt.show()

pause()


# In[18]:


fig7, axs7 = plt.subplots(1, 4, figsize=(25,5))

axs7[0].hist(nuemann1, bins=10)
axs7[0].set_title('I)')

axs7[1].hist(nuemann2, bins=10)
axs7[1].set_title('J)')

axs7[2].hist(nuemann3, bins=10)
axs7[2].set_title('K)')

axs7[3].hist((nuemann1 + nuemann2 + nuemann3)/3, bins=10)
axs7[3].set_title('L)')

for ax in axs7.flat:
    ax.set(xlabel='Value', ylabel='# of Times Value Appeared')
    
plt.show()

pause()


# In[19]:


fig8, axs8 = plt.subplots(1, 4, figsize=(25,5))

axs8[0].hist(nuemann1, bins=40, color='g')
axs8[0].set_title('M)')

axs8[1].hist(nuemann2, bins=40, color='g')
axs8[1].set_title('N)')

axs8[2].hist(nuemann3, bins=40, color='g')
axs8[2].set_title('O)')

axs8[3].hist((nuemann1 + nuemann2 + nuemann3)/3, bins=40, color='g')
axs8[3].set_title('P)')

for ax in axs8.flat:
    ax.set(xlabel='Value', ylabel='# of Times Value Appeared')
    
plt.show()

pause()


# In[20]:


fig9, axs9 = plt.subplots(1, 4, figsize=(25,5))

axs9[0].hist(nuemannUp1, bins=10)
axs9[0].set_title('Q)')

axs9[1].hist(nuemannUp2, bins=10)
axs9[1].set_title('R)')

axs9[2].hist(nuemannUp3, bins=10)
axs9[2].set_title('S)')

axs9[3].hist((nuemannUp1 + nuemannUp2 + nuemannUp3)/3, bins=10)
axs9[3].set_title('T)')

for ax in axs9.flat:
    ax.set(xlabel='Value', ylabel='# of Times Value Appeared')
    
plt.show()

pause()


# In[21]:


fig10, axs10 = plt.subplots(1, 4, figsize=(25,5))

axs10[0].hist(nuemannUp1, bins=40, color='g')
axs10[0].set_title('U)')

axs10[1].hist(nuemannUp2, bins=40, color='g')
axs10[1].set_title('V)')

axs10[2].hist(nuemannUp3, bins=40, color='g')
axs10[2].set_title('W)')

axs10[3].hist((nuemannUp1 + nuemannUp2 + nuemannUp3)/3, bins=40, color='g')
axs10[3].set_title('X)')

for ax in axs10.flat:
    ax.set(xlabel='Value', ylabel='# of Times Value Appeared')
    
plt.show()

pause()


# In[22]:


fig11, axs11 = plt.subplots(1, 4, figsize=(25,5))

axs11[0].hist(human1, bins=10)
axs11[0].set_title('Y)')

axs11[1].hist(human2, bins=10)
axs11[1].set_title('Z)')

axs11[2].hist(human3, bins=10)
axs11[2].set_title('A2)')

axs11[3].hist((human1 + human2 + human3)/3, bins=10)
axs11[3].set_title('B2)')

for ax in axs11.flat:
    ax.set(xlabel='Value', ylabel='# of Times Value Appeared')

plt.show()

pause()


# In[23]:


fig12, axs12 = plt.subplots(1, 4, figsize=(25,5))

axs12[0].hist(human1, bins=40, color='g')
axs12[0].set_title('C2)')

axs12[1].hist(human2, bins=40, color='g')
axs12[1].set_title('D2)')

axs12[2].hist(human3, bins=40, color='g')
axs12[2].set_title('E2)')

axs12[3].hist((human1 + human2 + human3)/3, bins=40, color='g')
axs12[3].set_title('F2)')

for ax in axs12.flat:
    ax.set(xlabel='Value', ylabel='# of Times Value Appeared')
    
plt.show()

pause()


# From my visual interaction with the data, I learned that most of these techniques are pretty good are creating random distributions of numbers, but John Von Nuemann's original is by far the worst of the ones I tested. From my histograms, you can see that most of the values from my plots were between 0.6 and 0.7. I believe this is because if it generated a number that ended in 625, it caused an infinite loop.

# # Biii.a #

# In[24]:


def chiHist(observed, bins):
    '''
    Takes:
        An observed data set, an expected data set, and a number of bins
        
    Parameters:
        observed : 1-D numpy.array of data
        expected : 1-D numpy.array of expected data, len(observed)
        bins : histogram-like bins that splits up the data, ideally a minimum of 5 numbers per bin
        
    Returns:
        The chi squared value between the obvserved and expected data sets
        The correlated p-value
    '''
    plt.hist(observed, bins)                                     # Create a histogram with the observed data
    
    axis = plt.gca()                                             # Assign an axis so we can extract the bin heights of the histogram

    patches = axis.patches

    heights = np.array([patch.get_height() for patch in patches])
        
    expected = len(observed)/bins                                 # Expected = Probability * Number of events
    
    chi = np.sum(((heights-expected)**2)/expected)                # Define chi squared according to the equation, and sum up over all the data
    
    dof = bins - 1                                                # Only have 1 constraint, so the # of degrees of freedom is equal to the # of bins - 1
    
    p = 1 - stats.chi2.cdf(chi, dof)                              # 1 - CDF = P-value
    
    return chi, p                                                 # Return chi squared and p-value


# In[25]:


def chiSquared(observed, expected):
    chi = np.sum(((observed-expected)**2)/expected) 
    
    return chi


# In[26]:


chiHist(uniform1, 10), chiHist(uniform1, 40), chiHist(uniform1, 100)


# In[27]:


chiHist(uniform2, 10), chiHist(uniform2, 40), chiHist(uniform2, 100)


# In[28]:


chiHist(uniform3, 10), chiHist(uniform3, 40), chiHist(uniform3, 100)


# In[29]:


chiHist(nuemann1, 10), chiHist(nuemann1, 40), chiHist(nuemann1, 100)


# In[30]:


chiHist(nuemann2, 10), chiHist(nuemann2, 40), chiHist(nuemann2, 100)


# In[31]:


chiHist(nuemann3, 10), chiHist(nuemann3, 40), chiHist(nuemann3, 100)


# In[32]:


chiHist(nuemannUp1, 10), chiHist(nuemannUp1, 40), chiHist(nuemannUp1, 100)


# In[33]:


chiHist(nuemannUp2, 10), chiHist(nuemannUp2, 40), chiHist(nuemannUp2, 100)


# In[34]:


chiHist(nuemannUp3, 10), chiHist(nuemannUp3, 40), chiHist(nuemannUp3, 100)


# In[35]:


chiHist(human1, 10), chiHist(human1, 40), chiHist(human1, 100)


# In[36]:


chiHist(human2, 10), chiHist(human2, 40), chiHist(human2, 100)


# In[37]:


chiHist(human3, 10), chiHist(human3, 40), chiHist(human3, 100)


# For most of my data, the p-values are either very small or zero, which implies that most of my data does not "pass" the frequency test. With the exception of uniform1, with a p-value of 0.98 with 10 bins. By rule of thumb, there should be at least 5 data points per bin, so with 1000 data points and 100 bins, we have more than enough numbers in each sequence for this to be a valid test. 

# # Biii.b #

# In[38]:


def serialTest(observed, bins):
    same = 0
    neighboring = 0
    
    for i in range(len(observed)-1):                                                            # For loop that adds 1 if two values in the observed data are in the same bin
        for j in range(bins):
            if j/bins <= observed[i] < (j+1)/bins and j/bins <= observed[i+1] < (j+1)/bins:
                same += 1
                
    for i in range(len(observed)-1):                                                            # For loop that adds 1 if two values in the observed data are in neighboring bins
        for j in range(bins):
            if j/bins <= observed[i] < (j+1)/bins and (j-1)/bins <= observed[i+1] < (j+2)/bins: 
                neighboring += 1
                
    neighboring -= same                                                                         # Account for the neighboring loop counting values in the same bin too
    
    return same, neighboring


# In[39]:


sameUni1, neighborUni1 = serialTest(uniform1, 10)               # 0.1 = 1/bins, so bins = 10

chiSquared(sameUni1, 1000/10), chiSquared(neighborUni1, 1000/5) # The odds of being in the same bin is 1/10 and the odds of being in a neighboring bin is 2/10


# In[40]:


sameUni2, neighborUni2 = serialTest(uniform2, 10) 

chiSquared(sameUni2, 1000/10), chiSquared(neighborUni2, 1000/5)


# In[41]:


sameUni3, neighborUni3 = serialTest(uniform3, 10) 

chiSquared(sameUni3, 1000/10), chiSquared(neighborUni3, 1000/5)


# In[42]:


sameNue1, neighborNue1 = serialTest(nuemann1, 10) 

chiSquared(sameNue1, 1000/10), chiSquared(neighborNue1, 1000/5)


# In[43]:


sameNue2, neighborNue2 = serialTest(nuemann2, 10) 

chiSquared(sameNue2, 1000/10), chiSquared(neighborNue2, 1000/5)


# In[44]:


sameNue3, neighborNue3 = serialTest(nuemann3, 10) 

chiSquared(sameNue3, 1000/10), chiSquared(neighborNue3, 1000/5)


# In[45]:


sameNueUp1, neighborNueUp1 = serialTest(nuemannUp1, 10) 

chiSquared(sameNueUp1, 1000/10), chiSquared(neighborNueUp1, 1000/5)


# In[46]:


sameNueUp2, neighborNueUp2 = serialTest(nuemannUp2, 10) 

chiSquared(sameNueUp2, 1000/10), chiSquared(neighborNueUp2, 1000/5)


# In[47]:


sameNueUp3, neighborNueUp3 = serialTest(nuemannUp3, 10) 

chiSquared(sameNueUp3, 1000/10), chiSquared(neighborNueUp3, 1000/5)


# In[48]:


sameHum1, neighborHum1 = serialTest(human1, 10) 

chiSquared(sameHum1, 1000/10), chiSquared(neighborHum1, 1000/5)


# In[49]:


sameHum2, neighborHum2 = serialTest(human2, 10) 

chiSquared(sameHum2, 1000/10), chiSquared(neighborHum2, 1000/5)


# In[50]:


sameHum3, neighborHum3 = serialTest(human3, 10) 

chiSquared(sameHum3, 1000/10), chiSquared(neighborHum3, 1000/5)


# For most of these tests, my chi-squared value is relatively low, besides my data for nuemann1 and nuemann3. This implies that the number of times data landed in the same or neighboring bins was close to the expected amount for most of my data sets. However, since I got high chi-squared values for nuemann1 and nuemann3, this implies that the original Nuemann technique is a poor random number generator. 

# # Thought Questions #

# For a sequence of number to be psuedorandom, it means the data is indistinguishable from "real" random data but isn't truly random. Properties you would like a psuedorandom sequence to have are a uniform distribution, no visible patterns, and comprised of lots of data. Some of my random sequences exhibit these properties, but most of them (namely the 2 Nuemann techniques) don't have a uniform distribution, and also very visible patterns. 

# In Part A(iv), if you constructed the time series by thinking up numbers, the largest bias you would expect is not using digits that you just used. In a large, real random sequence, you expect to have many repeating or similar digits by chance, but when thinking up random numbers as a human, we often try to prevent repeating numbers or similar digits (which has the opposite effect; makes it easier to spot a human-made "random" sequence).

# A relatively short sequence compared to a very long one have drastic differences: In a very long sequence, we expect long chains of the same number, compared to a relatively short one, where we expect short chains of the same number. The key difference is that if you took a slice of the long sequence, there's a good chance it wouldn't look random compared to a slice of the short sequence. 

# Aside from engineering practicality, scientists will likely choose a pseudo-random number generator over a radioactive source coupled with a Geiger counter because pseudo-random generators are often much better distributed (especially if it's a short sequence). In the example of numerically integrating something by just plopping down random numbers on a graph, you would want a more uniformly distributed sequence of random numbers to ensure an approximate solution with relatively few random numbers. 

# # Comment #

# This project was honestly very interesting (albeit somewhat confusing at points) because I find it fascinating how random number generators work. I loved being given the opportunity to create my own random number generators, and compare them against each other. 
