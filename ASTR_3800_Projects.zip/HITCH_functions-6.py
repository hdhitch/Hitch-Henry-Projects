#!/usr/bin/env python
# coding: utf-8

# In[1]:


def pause():
    
    # pauses until a keyboard entry (e.g. carrage return)
    
    print('\r')     
    dummy = input('Pause')     
    print('\r')


# In[2]:


def nuemann(x, y):
    '''
    Takes:
        A 6-digit seed number [x], and returns a list length [y + 1] of random numbers
    
    Parameters:
        x : 6-digit seed
        y : desired length of list - 1
        
    Returns:
        List length [y + 1] full of psuedo-random numbers using Jon Von Nuemanns original technique
    '''
    
    first = str(x**2)             # First seed gets squared and converted into a string for splicing
    
    list1 = [x]                   # Define a list that starts with our input seed
    
    for i in range(y):
        newSeed = int(first[3:9]) # First string is spliced to take the middle 6 digits and turn them back into an integer
        
        first = str(newSeed**2)   # Redefine the string as the new seed squared
        
        list1.append(newSeed)     # Append the new seed to list1
            
    return list1                  # Return list 1


# In[3]:


def nuemannUpdated(x, y):
    '''
    Takes: 
        A 6-digit seed number [x], and returns a list length [y + 1] of pseudo-random numbers
    
    Parameters:
        x : 6-digit seed
        y : desired length of list
        
    Returns:
        List length [y + 1] full of psuedo-random numbers using an updated Nuemann technique which doesnt generate infinite loops or 0s as often
    '''
    
    
    first = str(x**2)                           # First seed gets squared and converted into a string for splicing
    
    list1 = [x]                                 # Define a list that starts with our input seed
    
    for i in range(y):
        
        newSeed = int(first[3:9])
        
        if newSeed%100 == 0 or newSeed < 100000: # If the new seed is evenly divisble by 100 or less than 6 digits, does something different with the number
            
            first = str((newSeed+123456)**2)     # Takes the current seed and adds 123456 to it
            
            list1.append(newSeed)                # Appends back to the list
            
        else:                                    # Otherwise, applies Jon Von Nuemann's original techinque 
            first = str(newSeed**2)
            list1.append(newSeed)
            
    return list1


# In[4]:


def chiHist(observed, bins):
    '''
    Takes:
        An observed data set, an expected data set, and a number of bins
        
    Parameters:
        observed : 1-D numpy.array of data
        expected : 1-D numpy.array of expected data, len(observed)
        bins : histogram-like bins that splits up the data, ideally a minimum of 5 numbers per bin
        
    Returns:
        The chi squared value between the obvserved and expected data sets
        The correlated p-value
    '''
    plt.hist(observed, bins)                                     # Create a histogram with the observed data
    
    axis = plt.gca()                                             # Assign an axis so we can extract the bin heights of the histogram

    patches = axis.patches

    heights = np.array([patch.get_height() for patch in patches])
        
    expected = len(observed)/bins                                 # Expected = Probability * Number of events
    
    chi = np.sum(((heights-expected)**2)/expected)                # Define chi squared according to the equation, and sum up over all the data
    
    dof = bins - 1                                                # Only have 1 constraint, so the # of degrees of freedom is equal to the # of bins - 1
    
    p = 1 - stats.chi2.cdf(chi, dof)                              # 1 - CDF = P-value
    
    return chi, p                                                 # Return chi squared and p-value


# In[5]:


def chiSquared(observed, expected):
    chi = np.sum(((observed-expected)**2)/expected) 
    
    return chi


# In[6]:


def serialTest(observed, bins):
    same = 0
    neighboring = 0
    
    for i in range(len(observed)-1):                                                            # For loop that adds 1 if two values in the observed data are in the same bin
        for j in range(bins):
            if j/bins <= observed[i] < (j+1)/bins and j/bins <= observed[i+1] < (j+1)/bins:
                same += 1
                
    for i in range(len(observed)-1):                                                            # For loop that adds 1 if two values in the observed data are in neighboring bins
        for j in range(bins):
            if j/bins <= observed[i] < (j+1)/bins and (j-1)/bins <= observed[i+1] < (j+2)/bins: 
                neighboring += 1
                
    neighboring -= same                                                                         # Account for the neighboring loop counting values in the same bin too
    
    return same, neighboring


# In[7]:


def neighbor(data):
    '''
    Takes a 2-D numpy array of x and y star positions, and returns the distance of the closest star, for each star
    
    Parameters:
        data : 2-D numpy array full of star positions
        
    Returns:
        Numpy array with length (# of stars) full of closest star distances for each star
    '''
    
    x, y = data.shape                                          # extract the shape of input array
    
    emptyList = []                                             # define an empty list for appending

    for i in range(x):                                         # loop through all the stars
    
        emptyList2 = []                                        # define another empty list for appending
    
        for j in range(x-1):                                   # loop through all the stars (excluding reference star)
        
            if j+1 != i:
        
                xDistance = (data[i, 0] - data[j+1, 0])**2     # find the change in x and square it
        
                yDistance = (data[i, 1] - data[j+1, 1])**2     # find the change in y and square it
        
                totalDistance = np.sqrt(xDistance + yDistance) # add the distances and take the square root
        
            emptyList2.append(totalDistance)                   # append distances to empty list
    
        nearest = np.min(np.array(emptyList2))                 # extract only the smallest distance
    
        emptyList.append(nearest)                              # append shortest neighboring star distances to empty list
    
    nearestNeighbors = np.array(emptyList)                     # convert to numpy array
    
    return nearestNeighbors


# In[8]:


def imgData(file1, file2):
    '''
    Takes:
        Two strings of file names with data
        
    Parameters:
        file1 : a string of your desired file name containing data, with same time as file2
        file2 : a string of your desired file name containing data, with same time as file1
        
    Returns:
        A 2-D numpy array with the time, average width, and RMSA data for both filter RDC data
    '''
    data1 = pyfits.open(file1)                  # use astropy.io to open the files
    data2 = pyfits.open(file2)
    
    time = data1[0].header['JULDATE']           # extract the time variable from the header of one of the files
    
    avgWidth1 = data1[0].header['AVGWIDTH']     # extract the Average Width data from the headers of the files
    avgWidth2 = data2[0].header['AVGWIDTH']
    
    rmsa1 = data1[0].header['RMSA']             # extract the RMSA data from the headers of the files
    rmsa2 = data2[0].header['RMSA']
    
    array1 = np.array([time, avgWidth1, rmsa1]) # define arrays for the both files, containing the time, average width, and RMSA data
    array2 = np.array([time, avgWidth2, rmsa2])
    
    finalArray = np.array([array1, array2])     # define a final array with both file arrays inside
    
    return finalArray                           # return the final array


# In[9]:


def fit_correction(x,y,r,d):
    """
    This function will fit Hubble's correction to his original dataset.
    This correction takes the form:
    v = Ho*r + Xcos(a)cos(d) + Ysin(a)cos(d) + Zsin(d)
    where v is the recessional velocity of a galaxy, r is the distance
    to the galaxy, a is the right ascension and d is the declination.
    Input:
    x = The distances to a set of galaxies
    y = The corresponding recessional velocities
    r = The corresponding right ascensions
    d = The corresponding declinations
    Output:
    fit = The linear fit to the corrected velocities and distances
    correction = The correction to the original velocities provided
    ---------------------------------------------------------------
    Example:
    V, D, ra, dec = np.genfromtxt(datafile).T
    fit, dV = fit_correction(D,V,ra,dec)
    """
    # Generating the X matrix for the correction model above
    X = np.vstack(( x,
                    np.cos(r)*np.cos(d),
                    np.sin(r)*np.cos(d),
                    np.sin(d) ))
    
    # Fitting and reporting the coefficients of the fit
    A = np.dot( np.linalg.inv(np.dot(X,X.T)), np.dot(y,X.T) )
    print("Ho: {}, X: {}, Y: {}, Z: {}".format(*tuple(A)))
    
    # Finding the fit and correction
    fit = x * A[0]
    correction = np.dot(A[1:],X[1:])
    
    # Finding and reporting the chi square and p values
    x2 = ( (y-fit)**2 / np.var(y-fit) ).sum()
    p = 1 - stats.chi2.cdf(x2, x.size - 2)
    print("X2: {}, p-val: {}".format(x2,p))
    return fit, correction


# In[10]:


def findShift(fluxes):
    '''
    Takes: 
        Array or list of different flux arrays
        
    Parameters:
        fluxes : array or list full of multiple transit fluxes
        
    Returns:
        list of time-shifts to maximize the cross correlation between the reference flux data and the other transit fluxes
    '''
    
    shifts = []
    
    for i in fluxes:
        
        crossCor = np.fft.ifft(np.fft.fft(i)*np.conj(np.fft.fft(newFlux2)))
        
        shift = np.where(crossCor == np.max(crossCor))
        
        shifts.append(shift)
        
    return shifts

